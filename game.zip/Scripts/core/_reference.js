/// <reference path="../../typings/tsd.d.ts" />
/// <reference path="../objects/keyboardcontrols.ts" />
/// <reference path="../objects/mousecontrols.ts" />
/// <reference path="../config/screen.ts"/>
/// <reference path="../objects/point.ts"/>
/// <reference path="../objects/control.ts" />
/// <reference path="../objects/gameobject.ts"/> 
//# sourceMappingURL=_reference.js.map